gc 8.0.4
glm 0.9.9.6
Box2D 2.3.0
assimp 5
glew 2.1.0
ogg 1.3.4
vorbis 1.3.6
openal-soft 1.20.1
SDL2 2.0.12
SDL_ttf 2.0.15
	zlib1
	libfreetype-6
tinyxml 2.6.2
